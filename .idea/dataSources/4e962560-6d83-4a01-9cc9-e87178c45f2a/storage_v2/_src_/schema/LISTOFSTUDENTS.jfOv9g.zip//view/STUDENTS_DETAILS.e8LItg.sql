CREATE VIEW STUDENTS_DETAILS AS
  select stud_id, fam, im, ot, spec, kurs, gr from students
/

