CREATE procedure "COUNT_GROUP"
(gr OUT VARCHAR2,
count OUT NUMBER)
is
begin
select count(*) into count from students where gr=gr;
end;
/

