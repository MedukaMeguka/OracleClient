CREATE TRIGGER BI_STUDENTS
  BEFORE INSERT
  ON STUDENTS
  FOR EACH ROW
  begin   
  if :NEW."STUD_ID" is null then 
    select "STUDIDS".nextval into :NEW."STUD_ID" from dual; 
  end if; 
end;
/

