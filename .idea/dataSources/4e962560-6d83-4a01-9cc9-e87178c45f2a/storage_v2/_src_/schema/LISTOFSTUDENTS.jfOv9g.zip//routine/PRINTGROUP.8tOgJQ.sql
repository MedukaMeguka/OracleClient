CREATE procedure printGroup(g in varchar2)

is

cursor c_stud is select fam from students where gr=g;

r_stud c_stud%ROWTYPE;

begin

open c_stud;

loop

fetch c_stud into r_stud;

exit when c_stud%NOTFOUND;

DBMS_OUTPUT.put_line(r_stud.fam);

end loop;

close c_stud;

end;
/

